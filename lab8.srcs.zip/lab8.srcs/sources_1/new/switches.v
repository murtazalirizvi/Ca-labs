`timescale 1ns / 1ps

// Lab 5 interface module: latches written data onto the 16 physical LEDs
module switches (
    input             clk,
    input             rst,
    input      [31:0] writeData,
    input             writeEnable,
    input             readEnable,
    input      [29:0] memAddress,
    output reg [31:0] readData = 0,  
    output reg [15:0] leds
);
    always @(posedge clk) begin
        if (rst)
            leds <= 16'd0;
        else if (writeEnable)
            leds <= writeData[15:0];
    end

endmodule
