`timescale 1ns / 1ps

module top_fsm_system (
    input  wire        clk,
    input  wire        pbin,
    input  wire [15:0] physical_sw,
    output wire [15:0] physical_leds
);

    wire rst;
    debouncer btn_db (.clk(clk), .pbin(pbin), .pbout(rst));

    wire wr_en = physical_sw[15];
    wire rd_en = ~physical_sw[15];

    wire [31:0] cpu_addr  = {22'd0, physical_sw[14:5]};
    wire [31:0] cpu_wdata = {27'd0, physical_sw[4:0]};

    wire [31:0] bus_rdata;
    wire [15:0] led_reg_out;

    addressDecoderTop mem_sys (
        .clk               (clk),
        .rst               (rst),
        .address           (cpu_addr),
        .readEnable        (rd_en),
        .writeEnable       (wr_en),
        .writeData         (cpu_wdata),
        .physical_switches ({11'd0, physical_sw[4:0]}),
        .readData          (bus_rdata),
        .physical_leds     (led_reg_out)
    );

    assign physical_leds = (physical_sw[14:13] == 2'b10) ? led_reg_out : bus_rdata[15:0];

endmodule
