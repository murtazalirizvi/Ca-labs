    `timescale 1ns / 1ps
    
    // Decodes address[9:8]: 00 = Data Memory, 01 = LEDs, 10 = Switches, 11 = unused
    module AddressDecoder (
        input  [9:8] address,
        input        readEnable,
        input        writeEnable,
        output reg   DataMemWrite,
        output reg   DataMemRead,
        output reg   LEDWrite,
        output reg   SwitchReadEnable
    );
        always @(*) begin // at deafault nothing would be selected
            DataMemWrite     = 1'b0;
            DataMemRead      = 1'b0;
            LEDWrite         = 1'b0;
            SwitchReadEnable = 1'b0;
            case (address)
                2'b00: begin
                    DataMemWrite = writeEnable;
                    DataMemRead  = readEnable;
                end
                2'b01: begin
                    LEDWrite = writeEnable;
                end
                2'b10: begin
                    SwitchReadEnable = readEnable;
                end
                default: begin
                end
            endcase
        end
    
    endmodule
