`timescale 1ns / 1ps
module addressDecoderTop (
    input      clk, rst,
    input  [31:0] address,
    input         readEnable, writeEnable,
    input  [31:0] writeData,
    input  [15:0] physical_switches,
    output [31:0] readData,
    output [15:0] physical_leds             );
    wire        mem_wr_sel, mem_rd_sel, led_wr_sel, sw_rd_sel;
    wire [31:0] mem_rdata, sw_rdata;
    AddressDecoder addr_dec (
        .address       (address[9:8]),
        .readEnable     (readEnable),
        .writeEnable  (writeEnable),
        .DataMemWrite   (mem_wr_sel),
        .DataMemRead      (mem_rd_sel),
        .LEDWrite   (led_wr_sel),
        .SwitchReadEnable (sw_rd_sel)               );

    DataMemory data_mem (
        .clk     (clk),
        .MemWrite   (mem_wr_sel),
        .address    (address[8:0]),
        .write_data (writeData),
        .read_data  (mem_rdata)             );

    switches led_ctrl (
        .clk      (clk),
        .rst     (rst),
        .writeData   (writeData),
        .writeEnable (led_wr_sel),
        .readEnable  (1'b0),
        .memAddress  (address[29:0]),
        .readData  (),
        .leds (physical_leds)          );

    leds sw_ctrl (
        .clk         (clk),
        .rst         (rst),
        .btns        (16'd0),
        .writeData   (32'd0),
        .writeEnable (1'b0),
        .readEnable  (sw_rd_sel),
        .memAddress  (address[29:0]),
        .switches    (physical_switches),
        .readData    (sw_rdata)              );

    assign readData = (address[9:8] == 2'b00) ? mem_rdata :
                      (address[9:8] == 2'b10) ? sw_rdata  : 32'd0;

endmodule
