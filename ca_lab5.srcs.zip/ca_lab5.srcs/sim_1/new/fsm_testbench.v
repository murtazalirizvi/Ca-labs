`timescale 1ns / 1ps
module fsm_testbench();
    reg clk, pbin;
    reg [15:0] physical_sw;
    wire [15:0] physical_leds;

    fsm t1 (clk, pbin, physical_sw, physical_leds);

    always #5 clk = ~clk;   // 100MHz

    initial begin
        clk = 0; pbin = 0; physical_sw = 16'd0;

        // press reset button
        #20 pbin = 1;
        #20 pbin = 0;
        #50;

        // Case 01: latch 5, count down, switches ignored while busy
        physical_sw = 16'd5;
        #250;

        // Case 02: switches held nonzero must NOT re-trigger (armed logic)
        physical_sw = 16'd12;
        #150;

        // release switches, then apply a new value
        physical_sw = 16'd0;
        #50;
        physical_sw = 16'd8;
        #250;
        physical_sw = 16'd0;
        #50;

        // Case 03: reset mid-count
        physical_sw = 16'd10;
        #70;
        pbin = 1;
        #20;
        pbin = 0;
        physical_sw = 16'd0;
        #100;

        $display("Simulation complete.");
        $finish;
    end
endmodule