`timescale 1ns/1ps
module countdown_testbench;
    reg         clk = 0, rst = 0;
    reg  [15:0] sw_val = 0;
    wire [15:0] led_val;
    wire        busy;
    integer     errors = 0;

    // TICK_DIV = 3 so the tick enable is visible in the waveform
    countdown_fsm #(.TICK_DIV(3)) dut (
        .clk(clk), .rst(rst), .sw_val(sw_val), .led_val(led_val), .busy(busy)
    );

    always #5 clk = ~clk;

    task check(input cond, input [255:0] msg);
        begin
            if (!cond) begin
                errors = errors + 1;
                $display("FAIL @%0t: %0s (led=%0d busy=%b)", $time, msg, led_val, busy);
            end
        end
    endtask

    initial begin
        $dumpfile("countdown_fsm.vcd");
        $dumpvars(0, tb_countdown_fsm);

        // reset
        rst = 1; repeat (2) @(posedge clk); rst = 0;
        @(posedge clk); #1;
        check(!busy && led_val == 0, "idle after reset");

        // sw = 0 keeps FSM waiting
        repeat (5) @(posedge clk); #1;
        check(!busy && led_val == 0, "stays idle while sw==0");

        // Test 1: sw = 5 -> latch, display, count down, return to idle
        sw_val = 16'd5;
        @(posedge clk); #1;
        sw_val = 16'd0;                       // user releases switches
        check(busy && led_val == 5, "latched 5 and displayed");
        wait (led_val == 3); #1;
        check(busy, "still counting at 3");
        wait (!busy); #1;
        check(led_val == 0, "LEDs 0 after countdown");

        // Test 2: switches change mid-count must be ignored
        repeat (3) @(posedge clk);
        sw_val = 16'd4;
        @(posedge clk); #1;
        sw_val = 16'd9;                       // should be ignored
        wait (led_val == 2); #1;
        check(led_val == 2, "count unaffected by switch change");
        sw_val = 16'd0;
        wait (!busy); #1;
        check(led_val == 0, "second countdown finished");

        // Test 3: reset mid-count
        repeat (3) @(posedge clk);
        sw_val = 16'd12;
        @(posedge clk); #1;
        sw_val = 16'd0;
        wait (led_val == 10);
        rst = 1; @(posedge clk); #1; rst = 0;
        check(!busy && led_val == 0, "reset clears counter and LEDs");
        repeat (5) @(posedge clk); #1;
        check(!busy, "stays idle after reset");

        // Test 4: max value latches correctly
        sw_val = 16'hFFFF; @(posedge clk); #1; sw_val = 0;
        check(busy && led_val == 16'hFFFF, "latched 0xFFFF");
        rst = 1; @(posedge clk); #1; rst = 0;

        if (errors == 0) $display("ALL TESTS PASSED");
        else             $display("%0d TEST(S) FAILED", errors);
        $finish;
    end
endmodule
