`timescale 1ns / 1ps
// Countdown FSM + decrement counter.
// Speed is controlled externally by clock_divider.v's MAX_COUNT -- this
// module just decrements once per "tick" pulse it's given (one clk-domain
// pulse per slow_clk edge), and no longer has its own TICK_DIV.
module countdown (
    input clk,
    input rst,          // synchronous, active high (debounced button)
    input [15:0] sw_val, // current switch value
    input tick,          // one-cycle pulse: decrement on this edge
    output [15:0] led_val,
    output busy
);
    localparam IDLE = 1'b0, COUNT = 1'b1;

    reg state;
    reg [15:0] cnt;
    reg armed;   // 1 = ready to accept a new (non-zero) switch value

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            cnt   <= 16'd0;
            armed <= 1'b1;
        end else begin
            case (state)
                IDLE: begin
                    if (armed && sw_val != 16'd0) begin
                        cnt   <= sw_val;      // latch the switches
                        state <= COUNT;
                        armed <= 1'b0;        // don't accept another value yet
                    end else if (!armed && sw_val == 16'd0) begin
                        armed <= 1'b1;        // switches released -> ready again
                    end
                end
                COUNT: begin
                    if (cnt == 16'd0)  state <= IDLE;      // done, stays disarmed
                    else if (tick)     cnt <= cnt - 1;      // switches ignored here
                end
            endcase
        end
    end

    assign led_val = cnt;
    assign busy = (state == COUNT);
endmodule