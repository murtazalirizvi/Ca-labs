`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: top_fsm_system
// Project Name: Counter
// Target Devices: Basys 3
//////////////////////////////////////////////////////////////////////////////////
//
// Positional port connections below -- order must exactly match each
// module's declaration. Order is noted above each instance.

module fsm (
    input wire clk,
    input wire pbin,
    input wire [15:0] physical_sw,
    output wire [15:0] physical_leds
);

    // DEBOUNCER (Cleans up the physical reset button signal)
    wire rst_clean;
    wire [31:0] switch_data; // hold the value read from the switches
    reg  [31:0] led_write_data = 32'd0; // counter value here
    wire slow_clk;

    // debouncer(clk, pbin, pbout)
    debouncer rst_db (clk, pbin, rst_clean);

    // leds(clk, rst, btns, writeData, writeEnable, readEnable, memAddress, switches, readData)
    leds switch_reader (
        clk, rst_clean,
        16'd0,          // btns -- not used for this FSM
        32'd0, 1'b0,    // writeData, writeEnable -- we don't write to switches
        1'b1, 30'd0,    // readEnable, memAddress -- always ON so we can monitor switches
        physical_sw,    // switches
        switch_data     // readData
    );

    // switches(clk, rst, writeData, writeEnable, readEnable, memAddress, readData, leds)
    switches led_writer (
        clk, rst_clean,
        led_write_data, 1'b1,  // writeData, writeEnable -- always ON so LEDs update instantly
        1'b0, 30'd0,            // readEnable, memAddress
        ,                       // readData -- ignored
        physical_leds           // leds
    );

    // clock_divider(clk_in, rst, clk_out)
    clock_divider ticker (clk, rst_clean, slow_clk);

    // ---------------- YOUR FSM AND COUNTER LOGIC ----------------

    // slow_clk is a real (slow) clock, not a pulse. Bring it into the clk
    // domain with a 2-FF synchronizer and edge-detect it so countdown gets
    // a clean one-cycle "tick" instead of running on a second clock.
    reg sync0 = 1'b0, sync1 = 1'b0, sync2 = 1'b0;
    always @(posedge clk) begin
        sync0 <= slow_clk;
        sync1 <= sync0;
        sync2 <= sync1;
    end
    wire tick = sync1 & ~sync2;   // one-cycle pulse on slow_clk's rising edge

    wire [15:0] sw_val = switch_data[15:0];
    wire [15:0] led_val;
    wire        busy;

    // countdown(clk, rst, sw_val, tick, led_val, busy)
    countdown core (clk, rst_clean, sw_val, tick, led_val, busy);

    always @(*) led_write_data = {16'd0, led_val};

endmodule